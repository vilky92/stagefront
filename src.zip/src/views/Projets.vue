<template>
  <div class="projets">
 
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'projets',

}
</script>