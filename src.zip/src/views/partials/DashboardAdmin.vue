<template>
    
</template>


<script>
import Logo from "@/components/Dashboardnavbard.vue";
export default {
  name: "MyDashboardnavbard",
  components: {
    Logo
  },
  props: {
    msg: String
  }
};